package ObjectsAndClasses.MoreExercise.P01CompanyRoster;

public class Department {

    private String department;

    public Department (String department) {
        this.department = department;
    }

    public String getDepartment() {
        return department;
    }

}
